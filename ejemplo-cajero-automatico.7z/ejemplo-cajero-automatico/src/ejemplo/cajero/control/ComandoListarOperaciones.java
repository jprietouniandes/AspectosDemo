  
package ejemplo.cajero.control;

import java.util.List;

import ejemplo.cajero.modelo.Banco;

import ejemplo.cajero.modelo.User;

/**
 * Comando usado para listar las cuentas 
 */
public class ComandoListarOperaciones implements Comando {

	@Override
	public String getNombre() {
		return "Lista operaciones";
	}
	@Override
	public void ejecutar(Banco contexto, User user) throws Exception {
		
		System.out.println("Listado de operaciones");
		System.out.println();
	
		for (String oper : user.getOperaciones()) {
			System.out.println(oper);
		}

	}

}