package ejemplo.cajero.control;

import ejemplo.cajero.modelo.Banco;
import ejemplo.cajero.modelo.User;

public class ComandoConsultaSaldo implements Comando{

	public String getNombre() {
		return "Consulta Saldo";
	}
	@Override
	public void ejecutar(Banco contexto, User user) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Saldo");
		System.out.println();	
		System.out.println(user.getAccount().getSaldo());
		
	}

}
