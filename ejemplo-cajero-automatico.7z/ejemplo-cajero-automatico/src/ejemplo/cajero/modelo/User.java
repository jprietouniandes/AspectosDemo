package ejemplo.cajero.modelo;

import java.util.ArrayList;
import java.util.List;

public class User {

	private String id;
	private String password;
	private Cuenta account;
	private List<String> operaciones = new ArrayList<>();
	
	public User(String id, String password, Cuenta account) {
		this.id =id;
		this.password = password;
		this.account  = account;
	}

	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Cuenta getAccount() {
		return account;
	}
	
	public void setCuenta(Cuenta account) {
		this.account = account;
	}	
	
	public List<String> getOperaciones() {
		return operaciones;
	}
		
}
